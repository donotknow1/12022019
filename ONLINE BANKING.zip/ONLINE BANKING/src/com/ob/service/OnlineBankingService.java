package com.ob.service;

import java.util.List;

import com.ob.dao.IOnlineBankingDao;
import com.ob.dao.OnlineBankingDao;
import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;

public class OnlineBankingService implements IOnlineBankingService{
	
	static IOnlineBankingDao daoobj;

	public OnlineBankingService() {
		daoobj=new OnlineBankingDao();
	}
	
	
	public int validateCustomerLoginDetails(int custuserid, String custpassword) {
		int accountid=daoobj.validateCustomerLoginDetails(custuserid,custpassword);
		return accountid;
	}
	
	@Override
	public int customerAccountBalance(int accountId) {
		
		return daoobj.customerAccountBalance(accountId);
	}
	
	@Override
	public void Request(int acc_id, String description) {
		daoobj.Request(acc_id,description);
		
	}
	
	public List<ServiceTracker> retrieveServiceTrackerByAccountId(int accountId){
		return daoobj.retrieveServiceTrackerByAccountId(accountId);
		
	}
	
	@Override
	public void createNewAccount(NewAccount newcustomer) {
		daoobj.createNewAccount(newcustomer);
		
	}
	@Override
	public void customerSignUp(CustomerSignUp  obs) {
		daoobj.customerSignUp(obs);
		
	}
	@Override
    public int updateLoginPassword(int userid,String loginPassword) {
		
		daoobj.updateLoginPassword(userid,loginPassword);
	}
	
	
	
	
	
	
	


}
